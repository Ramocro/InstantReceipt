package com.example.anouar.instantreceipt;

import android.media.Image;

public class bon {

    String winkelnaam;
    double prijs;
    Image bon;

    public bon(String winkelnaam, double prijs, Image bon) {
        this.winkelnaam = winkelnaam;
        this.prijs = prijs;
        this.bon = bon;
    }
}

