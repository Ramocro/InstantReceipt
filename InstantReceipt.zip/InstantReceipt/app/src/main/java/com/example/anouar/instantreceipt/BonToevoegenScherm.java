package com.example.anouar.instantreceipt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BonToevoegenScherm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bon_toevoegen_scherm);
    }
}
