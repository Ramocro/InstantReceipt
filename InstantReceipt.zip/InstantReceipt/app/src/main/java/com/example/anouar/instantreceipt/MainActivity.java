package com.example.anouar.instantreceipt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get button
        Button voegBonToe = findViewById(R.id.voegBonToe);
        // Give Button Action
        voegBonToe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBonToevoegenScherm();
            }
        });
        // Get button
        Button bonBekijken = findViewById(R.id.bekijkBon);
        // Give button action
        bonBekijken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBonBekijken();
            }
        });


        }
          public void openBonToevoegenScherm(){

           Intent openSchermBon = new Intent(MainActivity.this,BonToevoegenScherm.class);
           startActivity(openSchermBon);


          }
          public void openBonBekijken(){
            Intent OpenBonBekijken = new Intent(MainActivity.this,Bonnen.class);
            startActivity(OpenBonBekijken);
          }
    }

